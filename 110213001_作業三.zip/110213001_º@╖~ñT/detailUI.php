<p>詳細商品瀏覽(客戶)</p>
<hr />
<table width="1000" border="1">
  <tr>
    <td>序號</td>
    <td>商品名稱</td>
    <td>價錢</td>
    <td>商品概述</td>
    <td>edit</td>
  </tr>
<?php
require("dbconfig.php");
$productId = $_GET['id'];
// 使用商品 ID 查詢詳細資訊
$sql = "SELECT * FROM product WHERE id = ?";
$stmt = mysqli_prepare($db, $sql);
mysqli_stmt_bind_param($stmt, 'i', $productId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while ( $rs = mysqli_fetch_assoc($result)) { //用迴圈逐筆取出

	echo "<tr><td>" , $rs['id'] ,
	"</td><td>" , $rs['productName'],
	"</td><td>" , $rs['productCost'], 
	"</td><td>", $rs['productContent'],
  "</td><td><button onclick=''>加入購物車</button>",
	"</td></tr>";
}
?>
<button onclick="location.href='http://localhost/test/作業三/product_list.php'">返回</button>
</table>
