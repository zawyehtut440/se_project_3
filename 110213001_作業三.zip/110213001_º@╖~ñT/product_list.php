<p>商品瀏覽(客戶)</p>
<hr />
<table width="1000" border="1">
  <tr>
    <td>序號</td>
    <td>商品名稱</td>
    <td>價錢</td>
    <td>詳情</td>
    <td>edit</td>
  </tr>
<?php
require("dbconfig.php");
$sql = "select * from product;";
$stmt = mysqli_prepare($db, $sql);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while ($rs = mysqli_fetch_assoc($result)) {
    echo "<tr><td>", $rs['id'],
    "</td><td>", $rs['productName'],
    "</td><td>", $rs['productCost'],
    "</td><td><button onclick=\"location.href='http://localhost/test/作業三/detailUI.php?id={$rs['id']}'\">詳情</button>",
    "</td><td><button onclick=''>加入購物車</button>",
    "</td></tr>";
}
?>
</table>
